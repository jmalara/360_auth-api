'use strict';

const uuidv4 = require('uuid/v4');
let sUid = uuidv4(); // ⇨ '416ac246-e7ac-49ff-93b4-f7e94d997e6b'
console.log(sUid);